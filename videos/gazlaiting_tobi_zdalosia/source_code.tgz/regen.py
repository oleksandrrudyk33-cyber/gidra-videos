import sys, asyncio, importlib.util
sys.argv_ids = sys.argv[1:]
src = open("tts.py").read().split("async def main")[0]
exec(src)
async def go():
    for l in LINES:
        if l["id"] in sys.argv_ids:
            print(await one(l))
asyncio.run(go())
