"""Ставить наголоси (U+0301) за словником stress_uk.txt, щоб Edge TTS читав правильно.
mark(text) -> текст для TTS;  strip(text) -> прибирає знаки наголосу (для субтитрів).
missing(text) -> багатоскладові слова, яких немає в словнику (їх треба додати)."""
import os, re
ACUTE = "́"
VOW = "аеєиіїоуюяАЕЄИІЇОУЮЯ"
_here = os.path.dirname(os.path.abspath(__file__))
D = {}
for f in [os.path.join(_here, "stress_uk.txt"), "stress_extra.txt"]:
    if os.path.exists(f):
        for line in open(f, encoding="utf-8"):
            if line.startswith("#"):
                continue
            for w in line.split():
                out = ""
                for c in w:
                    out += c.lower() + ACUTE if (c in VOW and c.isupper()) else c
                D[w.lower()] = out
WORD = re.compile(r"[А-Яа-яІіЇїЄєҐґ'’\-]+")


def _one(m):
    w = m.group(0)
    k = w.lower().replace("’", "'")
    if k not in D:
        return w
    s = D[k]
    return s[0].upper() + s[1:] if w[0].isupper() else s


def mark(text):
    return WORD.sub(_one, text)


def strip(text):
    return text.replace(ACUTE, "")


def missing(text):
    out = []
    for w in WORD.findall(text):
        k = w.lower().replace("’", "'").strip("-")
        if sum(c in VOW for c in k) >= 2 and k not in D and ACUTE not in k:
            out.append(k)
    return out
