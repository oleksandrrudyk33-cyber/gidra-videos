"""Перевірка озвучки: розпізнає кожну репліку (faster-whisper medium) і порівнює з текстом.
Запуск у теці відео після tts.py:  python3 asr_check.py  -> asr_report.txt"""
import os, re, sys, difflib, importlib
sys.path.insert(0, os.getcwd())
from faster_whisper import WhisperModel
import subprocess, numpy as np

def load16k(f):
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", f, "-f", "f32le", "-ac", "1", "-ar", "16000", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(r, np.float32)
from script_data import LINES

def norm(s):
    s = s.replace("́", "").lower().replace("’", "'")
    return re.findall(r"[а-яіїєґ']+|\d+", s)

m = WhisperModel("medium", device="cpu", compute_type="int8")
tot = bad = 0
rep = []
for L in LINES:
    segs, _ = m.transcribe(load16k(f"tts/{L['id']}.wav"), language="uk", beam_size=5, condition_on_previous_text=False)
    hyp = " ".join(s.text for s in segs).strip()
    a, b = norm(L["text"]), norm(hyp)
    sm = difflib.SequenceMatcher(None, a, b)
    errs = [(op, " ".join(a[i1:i2]), " ".join(b[j1:j2])) for op, i1, i2, j1, j2 in sm.get_opcodes() if op != "equal"]
    tot += len(a); bad += sum(max(i2 - i1, j2 - j1) for op, i1, i2, j1, j2 in sm.get_opcodes() if op != "equal")
    rep.append(f"{L['id']} {'OK ' if not errs else 'ERR'} | {L['text']}\n      ASR: {hyp}" + ("".join(f"\n      {o}: «{x}» → «{y}»" for o, x, y in errs)))
rep.append(f"\nWER ≈ {bad / max(tot,1):.1%} ({bad}/{tot})")
open("asr_report.txt", "w").write("\n".join(rep))
print("\n".join(rep[-1:]))
