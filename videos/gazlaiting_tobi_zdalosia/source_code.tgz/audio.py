"""Synth music + sfx, mix with voices -> mix.wav (then loudnorm to -14 LUFS)."""
import json, wave
import numpy as np

SR = 48000
TL = json.load(open("timeline.json"))
N = int(TL["total"] * SR) + SR
rng = np.random.default_rng(3)
L = {l["id"]: l for l in TL["lines"]}


def env_adsr(n, a=0.005, r=0.3):
    t = np.arange(n) / SR
    e = np.minimum(1, t / a) * np.exp(-t / r)
    return e


def pluck(f, dur, r=0.25, harm=(1, 0.5, 0.25)):
    n = int(dur * SR); t = np.arange(n) / SR
    s = sum(h * np.sin(2 * np.pi * f * (i + 1) * t) for i, h in enumerate(harm))
    return s * env_adsr(n, 0.004, r)


def bell(f, dur):
    n = int(dur * SR); t = np.arange(n) / SR
    s = np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * f * 2.76 * t) * np.exp(-t / 0.15) + 0.2 * np.sin(2 * np.pi * f * 5.4 * t) * np.exp(-t / 0.08)
    return s * env_adsr(n, 0.003, 0.5)


def add(buf, sig, t, g=1.0):
    i = int(t * SR)
    if i < 0:
        sig = sig[-i:]; i = 0
    j = min(len(buf), i + len(sig))
    buf[i:j] += sig[:j - i] * g


def hz(m):
    return 440 * 2 ** ((m - 69) / 12)


# ------------------------------------------------ music: sneaky detective waltz in A minor, 116 bpm 3/4
music = np.zeros(N)
beat = 60 / 116
prog = [(45, [60, 64, 69]), (45, [60, 64, 69]), (40, [59, 64, 68]), (45, [60, 64, 69]),
        (50, [62, 65, 69]), (45, [60, 64, 69]), (40, [59, 62, 68]), (45, [57, 60, 64])]
melody = [76, None, 75, 76, 72, 69, 71, None, 72, 74, 71, 68, 69, 72, 76, 77, 76, 74,
          72, None, 71, 69, 68, 69, 71, 72, 71, 69, None, None]
t = 0.0; bar = 0; mi = 0
while t < TL["total"]:
    root, ch = prog[bar % len(prog)]
    add(music, pluck(hz(root), 1.0, 0.3, (1, 0.6, 0.3, 0.15)), t, 0.5)
    for b in (1, 2):
        for m in ch:
            add(music, pluck(hz(m), 0.45, 0.08, (1, 0.4, 0.2)), t + b * beat, 0.1)
    for b in range(3):
        m = melody[mi % len(melody)]; mi += 1
        if m is not None and bar % 16 >= 1:
            add(music, pluck(hz(m), 0.6, 0.2, (1, 0.3, 0.5, 0.1, 0.15)), t + b * beat, 0.18)
    t += 3 * beat; bar += 1

# music gating: cut at pop (comic silence), back at l17; duck under speech
gate = np.ones(N)
a, b = int((L["l14"]["end"] + 0.05) * SR), int(L["l16"]["start"] * SR)
gate[a:b] = 0.25
duck = np.ones(N)
for l in TL["lines"]:
    i, j = int(l["start"] * SR), int(l["end"] * SR)
    duck[i:j] = 0.45
k = int(0.12 * SR)
kern = np.ones(k) / k
duck = np.convolve(duck, kern, mode="same")
gate = np.convolve(gate, np.ones(int(0.03 * SR)) / int(0.03 * SR), mode="same")
music *= duck * gate
fade = np.ones(N); fe = int((TL["total"] - 1.2) * SR); fade[fe:] = np.linspace(1, 0, N - fe)
music *= fade

# ------------------------------------------------ sfx
sfx = np.zeros(N)


def noise(dur):
    return rng.standard_normal(int(dur * SR))


def lowpass(x, a):
    y = np.zeros_like(x); acc = 0.0
    for i in range(len(x)):
        acc += a * (x[i] - acc); y[i] = acc
    return y


def whoosh(dur, up=True):
    n = noise(dur)
    tt = np.linspace(0, 1, len(n))
    e = np.sin(np.pi * tt) ** 2
    hp = n - lowpass(n, 0.05)
    return lowpass(hp, 0.25) * e


def thump(f0=90, dur=0.25):
    n = int(dur * SR); tt = np.arange(n) / SR
    f = f0 * np.exp(-tt * 6)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt / 0.08) + 0.3 * lowpass(noise(dur), 0.1) * np.exp(-tt / 0.05)


def popsnd():
    n = int(0.18 * SR); tt = np.arange(n) / SR
    f = 900 * np.exp(-tt * 18) + 200
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt / 0.06)


def hoot():
    out = np.zeros(int(1.0 * SR))
    for st, d in ((0, 0.35), (0.45, 0.45)):
        n = int(d * SR); tt = np.arange(n) / SR
        f = 420 * (1 + 0.02 * np.sin(2 * np.pi * 6 * tt)) * (1 - 0.08 * tt / d)
        s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * tt / d) ** 1.5
        out[int(st * SR):int(st * SR) + n] += s
    return out


def shimmer():
    out = np.zeros(int(1.6 * SR))
    for i, m in enumerate((81, 84, 88, 91, 93)):
        b_ = bell(hz(m), 1.0)
        add(out, b_, i * 0.09, 0.5)
    return out


def sting():
    out = np.zeros(int(1.2 * SR))
    for m in (38, 45, 50, 53):
        n = int(1.0 * SR); tt = np.arange(n) / SR
        s = np.sign(np.sin(2 * np.pi * hz(m) * tt)) * 0.3 + np.sin(2 * np.pi * hz(m) * tt)
        add(out, lowpass(s, 0.08) * np.exp(-tt / 0.35), 0, 0.5)
    return out


def cricket():
    out = np.zeros(int(1.0 * SR))
    for c in range(3):
        n = int(0.09 * SR); tt = np.arange(n) / SR
        s = np.sin(2 * np.pi * 4300 * tt) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 60 * tt))) * np.sin(np.pi * tt / 0.09)
        add(out, s, c * 0.32, 1)
    return out


def swap():
    out = np.zeros(int(0.7 * SR))
    add(out, popsnd(), 0, 0.8)
    for i, m in enumerate((84, 88, 91)):
        add(out, bell(hz(m), 0.6), 0.05 + i * 0.06, 0.4)
    return out


def register():
    out = np.zeros(int(1.2 * SR))
    for i in range(4):
        add(out, thump(300, 0.06), i * 0.07, 0.4)
    add(out, bell(hz(96), 1.0), 0.35, 1.0); add(out, bell(hz(100), 0.8), 0.38, 0.6)
    return out


def unroll():
    n = noise(1.0); tt = np.linspace(0, 1, len(n))
    return (n - lowpass(n, 0.2)) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 28 * tt))) * np.exp(-tt * 1.5)


def flicker():
    n = int(0.7 * SR); tt = np.arange(n) / SR
    hum = np.sin(2 * np.pi * 100 * tt) * 0.6 + np.sin(2 * np.pi * 200 * tt) * 0.3
    gate = (np.sin(2 * np.pi * 9 * tt + np.sin(2 * np.pi * 3 * tt) * 2) > -0.2).astype(float)
    return hum * gate * np.exp(-tt * 2.5) + noise(0.7)[:n] * 0.08 * gate


def scribble():
    n = noise(0.9); tt = np.linspace(0, 1, len(n))
    hp = n - lowpass(n, 0.3)
    return hp * (0.4 + 0.6 * np.abs(np.sin(2 * np.pi * 7 * tt))) * np.exp(-tt * 0.8)


def tick():
    out = np.zeros(int(2.0 * SR))
    for i in range(4):
        add(out, thump(1800 if i % 2 else 1400, 0.03), i * 0.5, 1)
    return out


def tweet():
    out = np.zeros(int(0.8 * SR))
    for st in (0, 0.18, 0.4):
        n = int(0.1 * SR); tt = np.arange(n) / SR
        f = 3000 + 1800 * tt / 0.1
        add(out, np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * tt / 0.1), st, 1)
    return out


GAIN = dict(swap=0.55, register=0.5, unroll=0.45, bird=0.12, card=0.5, swish=0.45, dig=0.9, toss=0.4, leap=0.5, pop=0.9, thud=0.7, owl=0.25, shimmer=0.35,
            sting=0.55, cricket=0.15, pop_ui=0.5, scream=0.0, flicker=0.35, scribble=0.3, tick=0.35)
for e in TL["events"]:
    s = e["s"]
    sig = {"card": lambda: whoosh(0.45), "swish": lambda: whoosh(0.22), "dig": lambda: thump(70, 0.3),
           "toss": lambda: whoosh(0.35), "leap": lambda: whoosh(0.3), "pop": popsnd, "thud": lambda: thump(120, 0.2),
           "owl": hoot, "shimmer": shimmer, "sting": sting, "cricket": cricket, "pop_ui": popsnd,
           "scream": lambda: np.zeros(10), "swap": swap, "register": register, "unroll": unroll, "bird": tweet, "flicker": flicker, "scribble": scribble, "tick": tick}[s]()
    sig = sig / (np.max(np.abs(sig)) + 1e-9)
    add(sfx, sig, e["t"], GAIN[s])

# ambience: soft wind + distant birds
amb = lowpass(noise(TL["total"] + 1), 0.01)
amb = amb[:N] if len(amb) >= N else np.pad(amb, (0, N - len(amb)))
amb = amb / np.max(np.abs(amb)) * 0.03

# ------------------------------------------------ voices
vox = np.zeros(N)
for l in TL["lines"]:
    w = wave.open(f"tts/{l['id']}.wav")
    a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float64) / 32768
    if False:  # scream: add echo
        e = np.zeros(len(a) + int(0.9 * SR)); e[:len(a)] += a
        for k_, g in ((0.18, 0.45), (0.36, 0.25), (0.54, 0.12)):
            e[int(k_ * SR):int(k_ * SR) + len(a)] += a * g
        a = e * 1.1
    add(vox, a, l["off"], 1.0)

mix = vox * 1.0 + music * 0.55 + sfx * 0.6 + amb
mix = mix[:int(TL["total"] * SR)]
mix /= max(1.0, np.max(np.abs(mix)) / 0.95)
with wave.open("mix_raw.wav", "w") as f:
    f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR)
    f.writeframes((mix * 32767).astype(np.int16).tobytes())
print("ok", len(mix) / SR)
