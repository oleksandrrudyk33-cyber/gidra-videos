import sys, asyncio, subprocess, numpy as np, edge_tts, os, difflib, re
from faster_whisper import WhisperModel
from script_data import VOICES
m=WhisperModel("medium",device="cpu",compute_type="int8")
v=VOICES[sys.argv[1]]
async def syn(t,f):
    c=edge_tts.Communicate(t,v["voice"],rate=v["rate"],pitch=v["pitch"],proxy=os.environ.get("HTTPS_PROXY"))
    await c.save(f)
for i,t in enumerate(sys.argv[2:]):
    asyncio.run(syn(t,f"/tmp/w/try{i}.mp3"))
    a=subprocess.run(["ffmpeg","-v","error","-i",f"/tmp/w/try{i}.mp3","-f","f32le","-ac","1","-ar","16000","-"],capture_output=True).stdout
    x=np.frombuffer(a,np.float32)
    segs,_=m.transcribe(x,language="uk",beam_size=5)
    print(f"{len(x)/16000:.2f}s | {t} | {' '.join(s.text for s in segs)}")
