"""Автопідбір вимови. Для кожної репліки з помилками розпізнавання пробує варіанти
(наголос на проблемному слові за словником stress_uk.txt, апостроф ʼ, паузи) і бере
той, що розпізнається найточніше. Перезаписує tts/<id>.wav/.mp3/.json, лог -> tune_log.txt.
Запуск у теці відео після tts.py:  python3 tune.py"""
import asyncio, json, os, re, subprocess, sys, difflib
import numpy as np
sys.path.insert(0, os.getcwd()); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import edge_tts, stress
from faster_whisper import WhisperModel
from script_data import LINES, VOICES
PROXY = os.environ.get("HTTPS_PROXY")
M = WhisperModel("medium", device="cpu", compute_type="int8")
NUM = {"й": "і"}

def norm(s):
    s = s.replace("́", "").lower().replace("’", "'").replace("ʼ", "'")
    return [NUM.get(w, w) for w in re.findall(r"[а-яіїєґ']+", s)]

def load16k(f):
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", f, "-f", "f32le", "-ac", "1", "-ar", "16000", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(r, np.float32)

def score(text, mp3):
    segs, _ = M.transcribe(load16k(mp3), language="uk", beam_size=5, condition_on_previous_text=False)
    hyp = " ".join(s.text for s in segs)
    a, b = norm(text), norm(hyp)
    return difflib.SequenceMatcher(None, a, b).ratio(), hyp, a, b

async def synth(say, v, base):
    c = edge_tts.Communicate(say, v["voice"], rate=v["rate"], pitch=v["pitch"], boundary="WordBoundary", proxy=PROXY)
    audio, words = bytearray(), []
    async for ch in c.stream():
        if ch["type"] == "audio": audio += ch["data"]
        elif ch["type"] == "WordBoundary":
            words.append(dict(t=ch["offset"] / 1e7, d=ch["duration"] / 1e7, w=stress.strip(ch["text"]).replace("ʼ", "'")))
    open(base + ".mp3", "wb").write(audio)
    return words

def variants(text, bad_words):
    out = [text]
    for w in bad_words:                       # наголос на одному проблемному слові
        mk = re.sub(rf"(?i)(?<![а-яіїєґ']){re.escape(w)}(?![а-яіїєґ'])", lambda m: stress.mark(m.group(0)), text)
        if mk != text: out.append(mk)
    allm = text
    for w in bad_words:
        allm = re.sub(rf"(?i)(?<![а-яіїєґ']){re.escape(w)}(?![а-яіїєґ'])", lambda m: stress.mark(m.group(0)), allm)
    out.append(allm)
    out.append(text.replace("'", "ʼ"))         # інший апостроф
    out.append(re.sub(r"\s—\s", ", ", text))   # тире -> кома
    return list(dict.fromkeys(out))

async def main():
    log = []
    os.makedirs("tts/tune", exist_ok=True)
    for L in LINES:
        v = VOICES[L["sp"]]
        s0, hyp, a, b = score(L["text"], f"tts/{L['id']}.mp3")
        if s0 >= 0.999: continue
        sm = difflib.SequenceMatcher(None, a, b)
        bad = [w for op, i1, i2, j1, j2 in sm.get_opcodes() if op != "equal" for w in a[i1:i2]]
        best = (s0, L.get("say", L["text"]), None, hyp)
        for k, say in enumerate(variants(L.get("say", L["text"]), bad)[1:]):
            base = f"tts/tune/{L['id']}_{k}"
            for attempt in range(3):
                try: words = await synth(say, v, base); break
                except Exception: await asyncio.sleep(2)
            else: continue
            s, h, _, _ = score(L["text"], base + ".mp3")
            if s > best[0] + 0.02: best = (s, say, (base, words), h)
        log.append(f"{L['id']} {s0:.2f} -> {best[0]:.2f} | {best[1]}\n      ASR: {best[3]}")
        if best[2]:
            base, words = best[2]
            os.replace(base + ".mp3", f"tts/{L['id']}.mp3")
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"tts/{L['id']}.mp3", "-ar", "48000", "-ac", "1", f"tts/{L['id']}.wav"], check=True)
            json.dump(words, open(f"tts/{L['id']}.json", "w"), ensure_ascii=False)
    open("tune_log.txt", "w").write("\n".join(log))
    print("\n".join(log))

asyncio.run(main())
