"""Builds timeline.json: line timing, words, mouth envelopes, sfx events."""
import json, wave
import numpy as np
from script_data import LINES

FPS = 30
GAP = 0.16
SR = 48000


def load(id_):
    w = wave.open(f"tts/{id_}.wav")
    a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
    idx = np.where(np.abs(a) > 0.01)[0]
    return a, idx[0] / SR, idx[-1] / SR


t = 0.0
out = []
for L in LINES:
    a, lead, tail = load(L["id"])
    t += L.get("pre", 0.0)
    start = t                      # speech start (absolute)
    off = start - lead             # where wav file begins
    words = json.load(open(f"tts/{L['id']}.json"))
    words = [dict(w=x["w"], t=round(off + x["t"], 3), d=round(x["d"], 3)) for x in words]
    # mouth envelope at FPS
    hop = SR // FPS
    n = len(a) // hop
    rms = np.array([np.sqrt(np.mean(a[i * hop:(i + 1) * hop] ** 2)) for i in range(n)])
    ref = np.percentile(rms[rms > 0.005], 90) if np.any(rms > 0.005) else 1
    env = np.clip(rms / ref, 0, 1.2)
    end = off + tail
    out.append(dict(L, start=round(start, 3), end=round(end, 3), off=round(off, 3),
                    words=words, env=[round(float(x), 3) for x in env]))
    t = end + GAP

total = t + 2.5  # tail for CTA screen
ev = []
T = {o["id"]: o for o in out}
for o in out:
    if o.get("card"):
        ev.append(dict(t=o["start"] - o["pre"] + 0.05, s="card"))
def wt(id_, word):
    for w in T[id_]["words"]:
        if w["w"].lower().startswith(word):
            return w["t"]
    return T[id_]["start"]
ev.append(dict(t=T["l01"]["start"] + 0.1, s="pop"))
ev.append(dict(t=T["l02"]["start"], s="sting"))
ev.append(dict(t=T["l05"]["start"], s="sting"))
ev.append(dict(t=wt("l08", "світло"), s="flicker"))
ev.append(dict(t=T["l09"]["start"] + 0.3, s="flicker"))
ev.append(dict(t=T["l10"]["start"], s="shimmer"))
ev.append(dict(t=T["l11"]["start"] + 0.2, s="scribble"))
ev.append(dict(t=T["l12"]["start"], s="tick"))
ev.append(dict(t=wt("l14", "шкірка"), s="sting"))
ev.append(dict(t=T["l15"]["start"] - 0.3, s="cricket"))
ev.append(dict(t=1.8, s="bird"))
ev.append(dict(t=T["l11"]["start"] - 0.5, s="bird"))
ev.append(dict(t=T["l18"]["start"], s="pop_ui"))
json.dump(dict(fps=FPS, total=round(total, 3), lines=out, events=ev), open("timeline.json", "w"),
          ensure_ascii=False, indent=0)
print("total", round(total, 2))
for o in out:
    print(o["id"], o["start"], o["end"])
