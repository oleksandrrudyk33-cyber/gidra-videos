"""Саша й Настя: шафа з ІКЕА без інструкції. 2D puppet renderer on skia-python.
usage: python3 render.py frames START END out.mp4   (frame range, video only)
       python3 render.py still T out.png
"""
import json, math, random, subprocess, sys
import numpy as np
import skia

W, H = 1080, 1920
TL = json.load(open("timeline.json"))
FPS = TL["fps"]
TOTAL = TL["total"]
LINES = TL["lines"]
LID = {l["id"]: l for l in LINES}
FONT_BLACK = skia.Typeface.MakeFromFile("/usr/share/fonts/opentype/inter/Inter-Black.otf")
FONT_XB = skia.Typeface.MakeFromFile("/usr/share/fonts/opentype/inter/Inter-ExtraBold.otf")
FONT_SB = skia.Typeface.MakeFromFile("/usr/share/fonts/opentype/inter/Inter-SemiBold.otf")
INK = (42, 36, 51)


def S(id_):
    return LID[id_]["start"]


def E(id_):
    return LID[id_]["end"]


# ---------------------------------------------------------------- helpers
def col(c, a=255):
    if isinstance(c, str):
        c = c.lstrip("#")
        c = tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
    return skia.Color(int(c[0]), int(c[1]), int(c[2]), int(a))


def mix(c1, c2, k):
    c1 = hexrgb(c1); c2 = hexrgb(c2)
    return tuple(c1[i] + (c2[i] - c1[i]) * k for i in range(3))


def hexrgb(c):
    if isinstance(c, str):
        c = c.lstrip("#")
        return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
    return c


def P(c, a=255, stroke=0, cap=True):
    p = skia.Paint(AntiAlias=True, Color=col(c, a))
    if stroke:
        p.setStyle(skia.Paint.kStroke_Style)
        p.setStrokeWidth(stroke)
        if cap:
            p.setStrokeCap(skia.Paint.kRound_Cap)
            p.setStrokeJoin(skia.Paint.kRound_Join)
    return p


def fo(cv, path, c, ow=6, a=255):
    """fill + outline"""
    cv.drawPath(path, P(c, a))
    if ow:
        cv.drawPath(path, P(INK, a, ow))


def oval(cx, cy, rx, ry):
    p = skia.Path()
    p.addOval(skia.Rect.MakeLTRB(cx - rx, cy - ry, cx + rx, cy + ry))
    return p


def rrect(x, y, w, h, r):
    p = skia.Path()
    p.addRRect(skia.RRect.MakeRectXY(skia.Rect.MakeXYWH(x, y, w, h), r, r))
    return p


def poly(pts, close=True):
    p = skia.Path()
    p.moveTo(*pts[0])
    for q in pts[1:]:
        p.lineTo(*q)
    if close:
        p.close()
    return p


def limb(cv, pts, c, w, ow=6):
    p = poly(pts, close=False)
    cv.drawPath(p, P(INK, 255, w + 2 * ow))
    cv.drawPath(p, P(c, 255, w))


def smooth(x):
    x = min(1.0, max(0.0, x))
    return x * x * (3 - 2 * x)


def clamp(x, a=0.0, b=1.0):
    return max(a, min(b, x))


def ramp(t, t0, t1):
    return smooth((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)


def lerp(a, b, k):
    if isinstance(a, (tuple, list)):
        return tuple(lerp(x, y, k) for x, y in zip(a, b))
    return a + (b - a) * k


class Track:
    """keyframes [(t, value)] with smooth transitions of length `tr` ending at key t."""

    def __init__(self, keys, tr=0.35):
        self.keys = sorted(keys, key=lambda k: k[0])
        self.tr = tr

    def __call__(self, t):
        v = self.keys[0][1]
        for i in range(1, len(self.keys)):
            tk, vk = self.keys[i][:2]
            tr = self.keys[i][2] if len(self.keys[i]) > 2 else self.tr
            if t >= tk:
                v = vk
            elif t > tk - tr:
                v = lerp(v, vk, smooth((t - (tk - tr)) / tr))
                break
            else:
                break
        return v


def text(cv, s, x, y, size, c, face=FONT_BLACK, align="c", outline=0, oc=INK, a=255):
    f = skia.Font(face, size)
    w = f.measureText(s)
    if align == "c":
        x -= w / 2
    elif align == "r":
        x -= w
    blob = skia.TextBlob.MakeFromString(s, f)
    if outline:
        p = P(oc, a, outline)
        cv.drawTextBlob(blob, x, y, p)
    cv.drawTextBlob(blob, x, y, P(c, a))
    return w


def tw(s, size, face=FONT_BLACK):
    return skia.Font(face, size).measureText(s)


# ---------------------------------------------------------------- speech
def speaking(t):
    for l in LINES:
        if l["off"] <= t < l["off"] + len(l["env"]) / FPS:
            i = int((t - l["off"]) * FPS)
            if 0 <= i < len(l["env"]):
                return l, l["env"][i]
    return None, 0.0


def mouth_of(who, t):
    l, e = speaking(t)
    if l and l["sp"] == who:
        # small smoothing with previous frame
        l2, e2 = speaking(t - 1 / FPS)
        e2 = e2 if (l2 and l2["sp"] == who) else 0
        return clamp(0.65 * e + 0.35 * e2, 0, 1)
    return 0.0


def cur_line(t):
    best = None
    for l in LINES:
        if l["start"] - l.get("pre", 0) - 0.01 <= t:
            best = l
    return best


# ---------------------------------------------------------------- time of day
def tod(t):
    """0 day, 1 golden, 3 night, back to morning ~0.3"""
    k = 0.0
    k += ramp(t, S("l07") - 0.7, S("l07") - 0.1) * 1.0
    k += ramp(t, S("l09"), S("l10") - 1.3) * 2.0
    k -= ramp(t, S("l14") - 0.8, S("l14") - 0.1) * 2.7
    return clamp(k, 0, 3)


SKY = [("#86c9ee", "#fdeccb"), ("#7fb8e6", "#ffd9a0"), ("#4a3f8a", "#e88a8a"), ("#1c1a45", "#3b3577")]


def sky_cols(k):
    i = min(2, int(k))
    f = k - i
    return mix(SKY[i][0], SKY[i + 1][0], f), mix(SKY[i][1], SKY[i + 1][1], f)


# ---------------------------------------------------------------- story timings
def wt(id_, word):
    for w in LID[id_]["words"]:
        if w["w"].lower().startswith(word):
            return w["t"]
    return S(id_)


JUMP = S("l04") - 0.45                     # cat leaps down from the top
HANG = wt("l05", "кульки")                 # balls go on the top
SWATS = [wt("l06", w) + 0.15 for w in ("три", "лапою", "очі")]
LIGHTS = S("l07") - 0.7                    # garland on, evening
TOSS = wt("l08", "викинув") + 0.25         # tinsel goes away
FALL = S("l10") - 1.15                     # crash
TIE = wt("l11", "мотуз") + 0.1             # tree back up, tied to ceiling
FOIL = wt("l13", "фольга")
MORNING = S("l14") - 0.8
STAND = wt("l14", "стоїть")


U = {k: 1e9 for k in ("pic", "table", "shelf", "mirror", "clock", "curtain", "carpet", "chair")}


def up(name, t):
    return 0.0


def pop_k(name, t):
    return 1.0


def sparkle(cv, x, y, t, t0, r=120):
    d = t - t0
    if not (0 <= d < 0.6):
        return
    k = d / 0.6
    for i in range(10):
        a = i / 10 * math.tau + 0.3
        rr = r * (0.4 + 0.9 * k)
        px, py = x + math.cos(a) * rr, y + math.sin(a) * rr
        s = 16 * (1 - k) + 4
        star = poly([(px, py - s * 1.8), (px + s * 0.45, py - s * 0.45), (px + s * 1.8, py), (px + s * 0.45, py + s * 0.45),
                     (px, py + s * 1.8), (px - s * 0.45, py + s * 0.45), (px - s * 1.8, py), (px - s * 0.45, py - s * 0.45)])
        cv.drawPath(star, P("#fff2a8", int(255 * (1 - k))))


# ---------------------------------------------------------------- background (room)
rng = random.Random(11)
PEOPLE = [(rng.uniform(0, 1), rng.choice([1, -1]), rng.choice(["#5b4b8a", "#3d5a80", "#7a3b4f", "#2f6b5a", "#8a5a2b"]),
           rng.uniform(30, 55), rng.random() < 0.6) for _ in range(7)]
BIRDS = [(rng.uniform(0, 1), rng.uniform(380, 520), rng.uniform(60, 110)) for _ in range(4)]
SNOW = [(rng.uniform(360, 720), rng.uniform(0, 1), rng.uniform(2, 5), rng.uniform(30, 60)) for _ in range(40)]
WX0, WY0, WX1, WY1 = 360, 300, 720, 830   # window
FLOOR = 1260


def mini_tree(cv, x, y, s, c="#2f7a4a"):
    for i in range(3):
        w = (34 - i * 8) * s
        yb = y - i * 16 * s
        fo(cv, poly([(x - w, yb), (x + w, yb), (x, yb - 34 * s)]), c, 3)


def outside(cv, t):
    k = tod(t)
    top, bot = sky_cols(k)
    cv.drawRect(skia.Rect.MakeLTRB(WX0, WY0, WX1, WY1), skia.Paint(Shader=skia.GradientShader.MakeLinear(
        [(0, WY0), (0, WY1)], [col(top), col(bot)])))
    if k < 2.6:
        sx, sy = 640 - k * 40, 380 + k * 90
        sun = mix("#fff3c4", "#ff9e6e", clamp(k / 2.5))
        cv.drawCircle(sx, sy, 110, skia.Paint(AntiAlias=True, Shader=skia.GradientShader.MakeRadial((sx, sy), 110, [col(sun, 150), col(sun, 0)])))
        cv.drawCircle(sx, sy, 36, P(sun, int(255 * clamp((2.6 - k) / 0.6))))
    if k > 2.2:  # moon + stars
        a = int(255 * clamp((k - 2.2) / 0.6))
        cv.drawCircle(420, 370, 30, P("#fff6d8", a))
        cv.drawCircle(434, 362, 26, P(mix(top, "#1c1a45", 0.2), a))
        for i in range(12):
            sx_, sy_ = 380 + (i * 97) % 330, 330 + (i * 53) % 220
            tw_ = 0.5 + 0.5 * math.sin(t * 3 + i)
            cv.drawCircle(sx_, sy_, 3, P("#ffffff", int(a * tw_)))
    # buildings across the street
    for bx, bw, bh, c2 in ((340, 120, 330, "#c79a8a"), (470, 150, 260, "#b7aecb"), (630, 130, 360, "#a6b8c8")):
        y0 = 760 - bh
        fo(cv, rrect(bx, y0, bw, bh + 40, 4), mix(c2, "#3a3060", clamp(k / 3)), 5)
        for r in range(int(bh // 60)):
            for c in range(int(bw // 45)):
                lit = clamp(k - 1.0) * (1 if (r * 3 + c + int(bx)) % 3 else 0)
                cv.drawRect(skia.Rect.MakeXYWH(bx + 14 + c * 45, y0 + 20 + r * 60, 24, 32),
                            P(mix("#5f6f9a", "#ffd56b", lit)))
        cx_ = bx + bw - 30
        fo(cv, rrect(cx_, y0 - 40, 20, 44, 3), "#8f86ad", 4)
        for i in range(5):
            ph = (t * 0.3 + i / 5 + bx * 0.001) % 1
            cv.drawCircle(cx_ + 10 + ph * 50 + math.sin(ph * 6 + i) * 8, y0 - 46 - ph * 200, 10 + ph * 26,
                          P("#ece8f2", int(140 * (1 - ph))))
    # christmas-tree market stall
    fo(cv, rrect(450, 690, 200, 90, 4), "#3e3552", 5)
    blinkon = (t * 2.2) % 1 < 0.7
    cv.drawRect(skia.Rect.MakeXYWH(460, 640, 180, 46), P("#c8283a"))
    cv.drawRect(skia.Rect.MakeXYWH(460, 640, 180, 46), P(INK, 255, 4))
    text(cv, "ЯЛИНКИ", 550, 678, 36, "#ffd23f" if blinkon else "#ffffff")
    for i in range(5):
        mini_tree(cv, 474 + i * 38, 775, 0.9, "#2f7a4a" if i % 2 else "#3f8a5a")
    # sidewalk + passers-by, some carry a tree
    cv.drawRect(skia.Rect.MakeLTRB(WX0, 770, WX1, WY1), P(mix("#9a93ae", "#3f3858", clamp(k / 3))))
    for ph, d, c, sp, tree in PEOPLE:
        x = WX0 - 60 + ((ph * 480 + d * t * sp) % 480)
        bob = abs(math.sin(t * 6 + ph * 9)) * 4
        fo(cv, poly([(x - 16, 830), (x, 768 - bob), (x + 16, 830)]), c, 4)
        fo(cv, oval(x, 760 - bob, 11, 12), "#f0c29e", 3)
        if tree:
            cv.save(); cv.translate(x + 14 * d, 800 - bob); cv.rotate(70 * d)
            mini_tree(cv, 0, 0, 0.7)
            cv.restore()
    if k < 2.4:
        for ph, y, sp in BIRDS:
            x = WX0 - 40 + ((ph * 500 + t * sp) % 500)
            f = math.sin(t * 10 + ph * 7) * 10
            p = skia.Path(); p.moveTo(x - 16, y - f); p.quadTo(x - 8, y - 8, x, y); p.quadTo(x + 8, y - 8, x + 16, y - f)
            cv.drawPath(p, P(INK, 255, 4))
    if t >= LIGHTS:  # it starts snowing in the evening
        a = int(220 * clamp((t - LIGHTS) / 2))
        for x, ph, r, sp in SNOW:
            y = WY0 + ((ph * 530 + t * sp) % 530)
            cv.drawCircle(x + math.sin(t + ph * 9) * 8, y, r, P("#ffffff", a))
    if t >= MORNING:  # snow on the sill outside
        cv.drawPath(rrect(WX0, WY1 - 22, WX1 - WX0, 30, 12), P("#ffffff"))


def frame_pic(cv, t):
    """left wall: old print -> gilded storm painting"""
    u = up("pic", t); k = pop_k("pic", t)
    cx, cy = 150, 520
    cv.save(); cv.translate(cx, cy); cv.scale(k, k)
    if u < 0.5:
        fo(cv, rrect(-90, -110, 180, 210, 4), "#e9e1cf", 5)
        cv.drawRect(skia.Rect.MakeLTRB(-70, -90, 70, 80), P("#cfc6b2"))
        for i in range(5):  # faded engraving
            cv.drawLine(-60, -70 + i * 30, 60, -60 + i * 30, P("#a49a86", 255, 3))
        cv.drawLine(-90, -110, -60, -80, P("#b5a98f", 255, 3))
    else:
        fo(cv, rrect(-120, -130, 240, 250, 10), "#d9a53a", 7)
        cv.drawRect(skia.Rect.MakeLTRB(-96, -106, 96, 96), P("#2f3f6a"))
        w = math.sin(t * 3) * 8
        sea = skia.Path(); sea.moveTo(-96, 30)
        for i in range(5):
            sea.quadTo(-80 + i * 40, 0 + w * (1 if i % 2 else -1), -56 + i * 40, 30)
        sea.lineTo(96, 96); sea.lineTo(-96, 96); sea.close()
        cv.drawPath(sea, P("#3f78a8"))
        fo(cv, poly([(-10, 10), (30, 10), (22, 30), (-4, 30)]), "#7a4a2a", 3)
        cv.drawLine(10, 10, 10, -40, P(INK, 255, 4))
        cv.drawPath(poly([(12, -40), (40, -6), (12, -6)]), P("#ffffff"))
        cv.drawLine(-60, -90, -40, -30, P("#fff6c0", 220, 4)); cv.drawLine(-40, -30, -55, -20, P("#fff6c0", 220, 4))
        for gx in (-120, 120):
            cv.drawCircle(gx, -130, 12, P("#ffd23f")); cv.drawCircle(gx, 120, 12, P("#ffd23f"))
    cv.restore()
    sparkle(cv, cx, cy, t, U["pic"], 150)


def table_(cv, t):
    u = up("table", t); k = pop_k("table", t)
    cx, base = 140, FLOOR + 40
    cv.save(); cv.translate(cx, base); cv.scale(k, k)
    if u < 0.5:
        fo(cv, rrect(-120, -170, 240, 24, 4), "#b08a5a", 5)
        for lx in (-100, 92):
            fo(cv, rrect(lx, -150, 14, 150, 3), "#9a7448", 4)
        fo(cv, rrect(-60, -200, 70, 30, 3), "#efe7d4", 4)   # papers pile
        cv.drawLine(-50, -190, 0, -190, P("#a49a86", 255, 3))
    else:
        fo(cv, rrect(-140, -190, 280, 30, 8), "#7a3b22", 6)
        fo(cv, rrect(-130, -162, 260, 92, 6), "#8f4a2a", 5)
        for dx in (-70, 70):
            fo(cv, rrect(dx - 46, -150, 92, 66, 5), "#a85a34", 4)
            cv.drawCircle(dx, -117, 7, P("#ffd23f"))
        for lx in (-124, 110):
            fo(cv, rrect(lx, -72, 16, 72, 4), "#5a2a18", 4)
        fo(cv, rrect(40, -236, 26, 46, 4), "#ffd23f", 4)  # inkwell
        cv.drawLine(54, -236, 80, -290, P("#ffffff", 255, 5))
    cv.restore()
    sparkle(cv, cx, base - 120, t, U["table"], 160)


def draw_background(cv, t, cam):
    k = tod(t)
    wall = mix("#e8cfa0", "#8a6a7a", clamp(k / 3))
    cv.drawRect(skia.Rect.MakeLTRB(0, 0, W, FLOOR), P(wall))
    stripe = mix("#dcbf8c", "#7a5a6e", clamp(k / 3))
    for x in range(0, W, 90):
        cv.drawRect(skia.Rect.MakeXYWH(x + 30, 0, 26, FLOOR), P(stripe))
        for y in range(40, FLOOR, 120):
            cv.drawCircle(x + 43, y + (x // 90 % 2) * 60, 7, P(mix(stripe, "#c06a50", 0.3)))
    fo(cv, rrect(-10, FLOOR - 30, W + 20, 40, 0), "#8a5a3a", 5)
    fl = mix("#b27a4a", "#5e3f4a", clamp(k / 3))
    cv.drawRect(skia.Rect.MakeLTRB(0, FLOOR + 10, W, H), P(fl))
    for i in range(-6, 14):
        x0 = 540 + i * 90
        cv.drawLine(540 + (x0 - 540) * 0.55, FLOOR + 10, 540 + (x0 - 540) * 1.6, H, P(mix(fl, "#3e2214", 0.3), 255, 4))
    for y in (1420, 1620, 1850):
        cv.drawLine(0, y, W, y, P(mix(fl, "#3e2214", 0.2), 255, 3))
    cv.save()
    cv.clipRect(skia.Rect.MakeLTRB(WX0, WY0, WX1, WY1))
    outside(cv, t)
    cv.restore()
    cv.drawRect(skia.Rect.MakeLTRB(WX0, WY0, WX1, WY1), P("#f4efe6", 255, 22))
    cv.drawLine((WX0 + WX1) / 2, WY0, (WX0 + WX1) / 2, WY1, P("#f4efe6", 255, 16))
    cv.drawLine(WX0, 520, WX1, 520, P("#f4efe6", 255, 16))
    cv.drawRect(skia.Rect.MakeLTRB(WX0 - 11, WY0 - 11, WX1 + 11, WY1 + 11), P(INK, 255, 5))
    fo(cv, rrect(WX0 - 40, WY1 + 6, WX1 - WX0 + 80, 28, 6), "#f4efe6", 5)
    if k < 2.5:
        sp = poly([(WX0 + 40, FLOOR + 30), (WX1 + 20, FLOOR + 30), (WX1 + 260, FLOOR + 380), (WX0 + 120, FLOOR + 380)])
        cv.drawPath(sp, P(mix("#fff0b0", "#ff9e6e", clamp(k / 2.5)), int(70 * clamp((2.5 - k) / 1.0))))
    cc, cc2 = "#d8cdb0", "#c2b694"
    for sgn, x in ((-1, WX0 - 30), (1, WX1 + 30)):
        sw = math.sin(t * 1.3 + sgn) * 6
        p = skia.Path(); p.moveTo(x, WY0 - 60)
        p.lineTo(x + sgn * 70, WY0 - 60); p.quadTo(x + sgn * 80 + sw, 600, x + sgn * 90 + sw, WY1 + 70)
        p.lineTo(x - sgn * 40 + sw, WY1 + 70); p.quadTo(x - sgn * 10, 600, x - sgn * 50, WY0 - 60); p.close()
        fo(cv, p, mix(cc, "#8a7a8a", clamp(k / 3)), 5)
        for j in range(3):
            cv.drawLine(x - sgn * 20 + j * sgn * 30, WY0 - 40, x - sgn * 10 + j * sgn * 34 + sw, WY1 + 50, P(cc2, 255, 6))
    fo(cv, rrect(WX0 - 120, WY0 - 80, WX1 - WX0 + 240, 22, 10), "#8a5a3a", 4)
    frame_pic(cv, t)
    table_(cv, t)
    fo(cv, rrect(WX1 - 40, WY1 - 50, 50, 46, 6), "#c0704a", 4)
    for i, a in enumerate((-30, 0, 30)):
        sw = math.sin(t * 1.2 + i) * 4
        cv.drawPath(oval(WX1 - 15 + a * 0.6 + sw, WY1 - 80, 12, 30), P("#5fa35a"))
    # ceiling hook above the tree (appears when Sasha ties the tree)
    if t >= TIE - 0.6:
        fo(cv, rrect(TX - 30, -10, 60, 26, 6), "#8f98a8", 4)
        hk = skia.Path(); hk.moveTo(TX, 14); hk.lineTo(TX, 40); hk.quadTo(TX + 22, 60, TX + 4, 72)
        cv.drawPath(hk, P(INK, 255, 12)); cv.drawPath(hk, P("#b8c0cc", 255, 6))
    # old rug in front
    fo(cv, oval(560, 1700, 230, 64), "#7a8a6a", 6)
    cv.drawPath(oval(560, 1700, 186, 46), P("#5f6f52", 255, 6))
    for i in range(-10, 11):
        cv.drawLine(560 + i * 20, 1762, 560 + i * 20 + 4, 1782, P("#7a8a6a", 255, 4))
    # warm glow of the garland in the evening / night
    if t >= LIGHTS:
        g = int(120 * clamp((t - LIGHTS) / 0.5) * (0.5 + 0.5 * clamp(k / 3)))
        gx, gy = tree_pt(0, -520, tree_rot(t))
        cv.drawCircle(gx, gy, 520, skia.Paint(AntiAlias=True, Shader=skia.GradientShader.MakeRadial(
            (gx, gy), 520, [col("#ffcf6a", g), col("#ffcf6a", 0)])))
    foil_(cv, t)
    tree_(cv, t)
    floor_balls(cv, t)


def draw_foreground(cv, t):
    pass


# ---------------------------------------------------------------- the tree
TX, TB = 845, FLOOR + 160          # trunk base (pivot)
GREEN, GREEN2 = "#2f8a4a", "#23703c"
BALLS = [(-55, -760, "#e8453c"), (60, -700, "#3f80e8"), (-95, -610, "#ffd23f"), (40, -620, "#ec6a8c"), (105, -560, "#e8453c")]
FALLERS = [2, 4, 0]                 # balls swatted at SWATS[i]
LOW_BALLS = [(-170, -260, "#3f80e8"), (150, -300, "#ffd23f"), (-40, -380, "#e8453c"), (110, -440, "#ec6a8c"), (-130, -470, "#ffd23f")]


def tree_rot(t):
    if t < JUMP:   # cat on the very top, the tree leans and wobbles
        return 6 + math.sin(t * 3.1) * 2.5
    if t < JUMP + 1.0:
        return 6 * math.exp(-(t - JUMP) * 4) * math.cos((t - JUMP) * 18)
    if S("l09") - 0.2 <= t < FALL:
        return math.sin(t * 15) * 1.5 * ramp(t, S("l09") - 0.2, S("l09") + 0.4)
    if FALL <= t < TIE:
        k = clamp((t - FALL) / 0.45)
        r = -64 * k * k
        if k >= 1:
            r = -64 + 3 * math.exp(-(t - FALL - 0.45) * 8) * math.sin((t - FALL) * 40)
        return r
    if TIE <= t < TIE + 0.7:
        k = smooth((t - TIE) / 0.7)
        return -64 * (1 - k)
    if STAND <= t < STAND + 1:
        return math.sin((t - STAND) * 14) * 2 * math.exp(-(t - STAND) * 4)
    return 0.0


def tree_pt(lx, ly, rot):
    a = math.radians(rot)
    return TX + lx * math.cos(a) - ly * math.sin(a), TB + lx * math.sin(a) + ly * math.cos(a)


def ball(cv, x, y, r, c):
    fo(cv, rrect(x - 9, y - r - 12, 18, 14, 3), "#d9a53a", 3)
    fo(cv, oval(x, y, r, r), c, 5)
    cv.drawPath(oval(x - r * 0.35, y - r * 0.35, r * 0.28, r * 0.2), P("#ffffff", 200))


def balls_on_tree(t):
    if t < HANG:
        return []
    out = []
    for i, b in enumerate(BALLS):
        if i in FALLERS and SWATS[FALLERS.index(i)] <= t < MORNING:
            continue
        out.append(b)
    if t >= MORNING:
        out += LOW_BALLS
    return out


def garland(cv, t):
    on = clamp((t - LIGHTS) / 0.4)
    cols = ["#ffd23f", "#e8453c", "#3f80e8", "#7be86a", "#ec6a8c"]
    for i in range(4):
        yb = -170 - i * 165 - 40
        w = 250 - i * 55
        p = skia.Path(); p.moveTo(-w + 20, yb - 60); p.quadTo(0, yb + 10, w - 20, yb - 90)
        cv.drawPath(p, P("#1d3a2a", 255, 4))
        for j in range(7):
            u = (j + 0.5) / 7
            x = (-w + 20) * (1 - u) ** 2 + 0 * 2 * u * (1 - u) + (w - 20) * u * u
            y = (yb - 60) * (1 - u) ** 2 + (yb + 10) * 2 * u * (1 - u) + (yb - 90) * u * u
            c = cols[(i * 7 + j) % 5]
            tw_ = 0.55 + 0.45 * math.sin(t * 5 + i * 1.7 + j * 2.3)
            cv.drawCircle(x, y, 22, P(c, int(90 * on * tw_)))
            cv.drawCircle(x, y, 9, P(mix("#555555", c, on * (0.6 + 0.4 * tw_))))


def tree_(cv, t):
    rot = tree_rot(t)
    cv.save(); cv.translate(TX, TB); cv.rotate(rot)
    # bucket + trunk
    fo(cv, rrect(-26, -190, 52, 110, 6), "#7a4a2a", 5)
    fo(cv, poly([(-90, -110), (90, -110), (70, 0), (-70, 0)]), "#c8283a", 6)
    cv.drawLine(-86, -86, 86, -86, P("#ffd23f", 255, 8))
    for i in range(4):
        yb = -170 - i * 165
        w = 270 - i * 58
        pts = [(-w, yb)]
        n = 6
        for j in range(n):
            x0 = -w + (2 * w) * (j + 0.5) / n
            pts.append((x0, yb - 26))
            pts.append((-w + (2 * w) * (j + 1) / n, yb + (10 if j % 2 else 0)))
        pts.append((0, yb - 290))
        fo(cv, poly(pts), GREEN if i % 2 == 0 else "#33944f", 6)
        cv.drawLine(-w * 0.5, yb - 40, -w * 0.15, yb - 120, P(GREEN2, 255, 5))
        cv.drawLine(w * 0.45, yb - 30, w * 0.1, yb - 140, P(GREEN2, 255, 5))
    if t >= LIGHTS:
        garland(cv, t)
    for bx, by, c in balls_on_tree(t):
        ball(cv, bx + math.sin(t * 2 + bx) * 2, by, 26, c)
    # star
    sy = -930
    s = 44
    star = poly([(0, sy - s), (s * 0.3, sy - s * 0.3), (s, sy - s * 0.2), (s * 0.45, sy + s * 0.25), (s * 0.6, sy + s),
                 (0, sy + s * 0.5), (-s * 0.6, sy + s), (-s * 0.45, sy + s * 0.25), (-s, sy - s * 0.2), (-s * 0.3, sy - s * 0.3)])
    if t >= LIGHTS:
        cv.drawCircle(0, sy, 70, P("#ffe27a", 90))
    fo(cv, star, "#ffd23f", 5)
    cv.restore()
    # rope to the ceiling hook
    if t >= TIE:
        k = clamp((t - TIE) / 0.7)
        topx, topy = tree_pt(0, -960, rot)
        cv.drawLine(topx, topy, TX + 4, 72, P("#d9c08a", 255, 6))
    if t >= STAND:
        sparkle(cv, TX, TB - 600, t, STAND, 240)


def floor_balls(cv, t):
    """swatted balls fall, bounce and roll to the left"""
    if t >= MORNING:
        return
    for n, i in enumerate(FALLERS):
        t0 = SWATS[n]
        if t < t0:
            continue
        bx, by, c = BALLS[i]
        x0, y0 = tree_pt(bx, by, 0)
        xf, yf = 700 - n * 70, 1690 + n * 18
        d = t - t0
        if d < 0.5:
            k = d / 0.5
            x = lerp(x0, xf, k); y = y0 + (yf - y0) * k * k
        else:
            b = d - 0.5
            x = xf - 30 * (1 - math.exp(-b * 3))
            y = yf - abs(math.sin(b * 9)) * 60 * math.exp(-b * 5)
        if FALL <= t:
            x -= 40 * clamp((t - FALL) / 0.6)
        ball(cv, x, y, 26, c)


def foil_(cv, t):
    if t < FOIL:
        return
    k = smooth(clamp((t - FOIL) / 0.5))
    cv.save(); cv.translate(TX, TB + 10); cv.scale(k, k)
    p = skia.Path()
    for i in range(36):
        a = i / 36 * math.tau
        r = 1.0 + (0.07 if i % 2 else -0.04)
        (p.moveTo if i == 0 else p.lineTo)(math.cos(a) * 250 * r, math.sin(a) * 70 * r)
    p.close()
    fo(cv, p, "#c9d1dc", 6)
    for i in range(9):
        a = i * 0.7
        x, y = math.cos(a) * 160, math.sin(a) * 40
        cv.drawLine(x - 30, y - 6, x + 26, y + 8, P("#ffffff", 220, 4))
        cv.drawLine(x + 6, y - 12, x - 12, y + 14, P("#8f98a8", 200, 3))
    cv.restore()


# ---------------------------------------------------------------- hand props
def tinsel(cv, x, y, rot, a=255):
    cv.save(); cv.translate(x, y); cv.rotate(rot)
    p = skia.Path(); p.moveTo(0, 0)
    for i in range(10):
        p.lineTo(14 * (1 if i % 2 else -1), 16 * (i + 1))
    cv.drawPath(p, P(INK, a, 10)); cv.drawPath(p, P("#dfe6ee", a, 5))
    for i in range(6):
        cv.drawCircle(math.sin(i * 2.1) * 12, 20 + i * 26, 3, P("#ffffff", a))
    cv.restore()


def rope_coil(cv, x, y):
    for r in (34, 26, 18):
        cv.drawPath(oval(x, y, r, r * 0.8), P(INK, 255, 10))
        cv.drawPath(oval(x, y, r, r * 0.8), P("#d9c08a", 255, 6))


def foil_roll(cv, x, y):
    fo(cv, rrect(x - 60, y - 16, 120, 32, 12), "#c9d1dc", 4)
    cv.drawLine(x - 40, y - 6, x + 40, y - 6, P("#ffffff", 220, 4))
    fo(cv, oval(x + 60, y, 8, 16), "#8f98a8", 3)


def zzz(cv, x, y, t, a=255):
    for i in range(3):
        ph = (t * 0.6 + i / 3) % 1
        text(cv, "z", x + ph * 60 + i * 6, y - ph * 120, 30 + 30 * ph, "#ffffff", outline=8, a=int(a * (1 - ph)))


# ---------------------------------------------------------------- characters
SKIN = "#f3c29d"


def human(cv, who, x, y, s, st, t):
    """st: dict with arms ((a1,a2),(a1,a2)), look, mouth, blink, brow, walk, lean, tilt, worried"""
    cv.save()
    cv.translate(x, y)
    cv.scale(s, s)
    cv.rotate(st.get("lean", 0))
    walk = st.get("walk", 0.0)
    wp = st.get("wphase", 0.0)
    breath = math.sin(t * 2.2 + (0 if who == "S" else 1.3)) * 4
    bounce = -abs(math.sin(wp)) * 14 * walk
    cv.translate(0, bounce)
    trousers = "#2d3352" if who == "S" else "#343a5e"
    # legs
    for sgn in (-1, 1):
        sw = math.sin(wp) * 26 * walk * sgn
        hip = (sgn * 34, -250)
        foot = (sgn * 40 + sw, -10)
        limb(cv, [hip, ((hip[0] + foot[0]) / 2 + sw * 0.2, -130), foot], trousers, 58)
        fo(cv, oval(foot[0] + 12 * sgn * 0.3 + 10, -6, 46, 20), "#eceff4", 5)
    if who == "S" and st.get("robe"):
        sk = poly([(-102, -270), (102, -270), (122, -70), (-122, -70)])
        fo(cv, sk, "#c8283a", 6)
        cv.drawLine(0, -262, 16, -74, P("#8e1426", 255, 6))
        cv.drawLine(-122, -84, 122, -84, P("#ffd23f", 255, 8))
    # torso
    sh = 95 if who == "S" else 86
    ty = -470 + breath
    torso = skia.Path()
    torso.moveTo(-sh, ty + 30); torso.quadTo(-sh, ty, -sh + 40, ty)
    torso.lineTo(sh - 40, ty); torso.quadTo(sh, ty, sh, ty + 30)
    torso.lineTo(sh - 18, -230); torso.lineTo(-sh + 18, -230); torso.close()
    if who == "S" and st.get("robe"):
        fo(cv, torso, "#c8283a", 6)
        fo(cv, poly([(-34, ty + 2), (34, ty + 2), (0, ty + 150)]), "#3f80e8", 4)
        cv.drawLine(-40, ty + 4, 6, -236, P("#ffd23f", 255, 10))
        cv.drawLine(40, ty + 4, -6, -236, P("#ffd23f", 255, 10))
        fo(cv, rrect(-sh + 14, -262, 2 * sh - 28, 22, 8), "#8e1426", 4)
        fo(cv, oval(56, -236, 16, 22), "#8e1426", 4)
    elif who == "S":
        fo(cv, torso, "#363b52", 6)
        shirt = poly([(-36, ty + 4), (36, ty + 4), (30, -232), (-30, -232)])
        fo(cv, shirt, "#3f80e8", 5)
        cv.drawLine(-36, ty + 10, -30, -230, P("#272b3d", 255, 5))
        cv.drawLine(36, ty + 10, 30, -230, P("#272b3d", 255, 5))
    else:
        fo(cv, torso, "#ec6a8c", 6)
        cv.drawLine(-sh + 24, -262, sh - 24, -262, P("#d0507a", 255, 8))
        cv.drawPath(oval(0, ty + 6, 34, 14), P("#d0507a"))
    # arms
    arms = st.get("arms", ((-10, -5), (10, 5)))
    hands = []
    for i, sgn in enumerate((-1, 1)):
        a1, a2 = arms[i]
        sx, sy = sgn * (sh - 14), ty + 26
        ex, ey = sx + 120 * math.sin(math.radians(a1)), sy + 120 * math.cos(math.radians(a1))
        hx, hy = ex + 112 * math.sin(math.radians(a2)), ey + 112 * math.cos(math.radians(a2))
        sleeve = ("#c8283a" if st.get("robe") else "#363b52") if who == "S" else "#ec6a8c"
        if who == "S":
            limb(cv, [(sx, sy), (ex, ey)], sleeve, 46)
            limb(cv, [(ex, ey), (hx, hy)], SKIN, 34)
            # tattoo on the right forearm
            if sgn == 1:
                mx, my = (ex * 0.55 + hx * 0.45), (ey * 0.55 + hy * 0.45)
                cv.drawCircle(mx, my, 7, P("#2f4d7a"))
                cv.drawCircle(mx + (hx - ex) * 0.18, my + (hy - ey) * 0.18, 5, P("#2f4d7a"))
                cv.drawCircle(mx - (hx - ex) * 0.18, my - (hy - ey) * 0.18, 5, P("#2f4d7a"))
            cv.drawLine(ex, ey, ex + (hx - ex) * 0.08, ey + (hy - ey) * 0.08, P("#ffd23f" if st.get("robe") else "#272b3d", 255, 40))
        else:
            limb(cv, [(sx, sy), (ex, ey), (hx - (hx - ex) * 0.2, hy - (hy - ey) * 0.2)], sleeve, 42)
        cv.drawCircle(hx, hy, 24, P(INK)); cv.drawCircle(hx, hy, 19, P(SKIN))
        hands.append((hx, hy))
    st["_hands"] = hands
    # neck + head
    tilt = st.get("tilt", 0)
    cv.save()
    cv.translate(0, ty)
    cv.rotate(tilt)
    fo(cv, rrect(-24, -40, 48, 50, 10), SKIN, 5)
    hy0 = -150
    look = st.get("look", 0.0)
    if who == "N":
        # hair back + bun
        fo(cv, oval(0, hy0 - 100, 46, 40), "#7a4630", 6)
        fo(cv, oval(0, hy0 - 6, 118, 124), "#7a4630", 6)
    fo(cv, oval(-106, hy0 + 6, 20, 26), SKIN, 5)
    fo(cv, oval(106, hy0 + 6, 20, 26), SKIN, 5)
    head = oval(0, hy0, 104, 118)
    fo(cv, head, SKIN, 6)
    if who == "S":
        hair = skia.Path(); hair.moveTo(-100, hy0 - 20)
        hair.quadTo(-100, hy0 - 120, 0, hy0 - 120); hair.quadTo(100, hy0 - 120, 100, hy0 - 20)
        hair.quadTo(60, hy0 - 78, -20, hy0 - 74); hair.quadTo(-80, hy0 - 70, -100, hy0 - 20); hair.close()
        fo(cv, hair, "#3a2b24", 5)
        beard = skia.Path(); beard.moveTo(-100, hy0 + 6)
        beard.quadTo(-96, hy0 + 130, 0, hy0 + 132); beard.quadTo(96, hy0 + 130, 100, hy0 + 6)
        beard.quadTo(70, hy0 + 40, 40, hy0 + 40); beard.quadTo(0, hy0 + 26, -40, hy0 + 40); beard.quadTo(-70, hy0 + 40, -100, hy0 + 6); beard.close()
        fo(cv, beard, "#5b3d2a", 5)
    else:
        fringe = skia.Path(); fringe.moveTo(-104, hy0 + 10)
        fringe.quadTo(-110, hy0 - 120, 0, hy0 - 118); fringe.quadTo(110, hy0 - 120, 104, hy0 + 10)
        fringe.quadTo(80, hy0 - 70, 10, hy0 - 72); fringe.quadTo(-70, hy0 - 64, -104, hy0 + 10); fringe.close()
        fo(cv, fringe, "#7a4630", 5)
        cv.drawCircle(-62, hy0 + 40, 18, P("#f08aa0", 120)); cv.drawCircle(62, hy0 + 40, 18, P("#f08aa0", 120))
    # eyes
    blink = st.get("blink", 1.0)
    wide = st.get("wide", 0.0)
    lid = st.get("lid", 0.0)
    for sgn in (-1, 1):
        ex, ey = sgn * 40, hy0 - 6
        er = 22 + 6 * wide
        cv.drawPath(oval(ex, ey, er, er * 1.15 * blink + 0.5), P("#ffffff"))
        cv.drawPath(oval(ex, ey, er, er * 1.15 * blink + 0.5), P(INK, 255, 4))
        if blink > 0.3:
            cv.drawCircle(ex + look * 9, ey + 2, 10 - 2 * wide, P(INK))
            cv.drawCircle(ex + look * 9 + 3, ey - 2, 3, P("#ffffff"))
        if lid > 0:
            cv.drawRect(skia.Rect.MakeLTRB(ex - er - 2, ey - er * 1.2 - 2, ex + er + 2, ey - er * 1.2 + er * 2.3 * lid * 0.5), P(SKIN))
            cv.drawLine(ex - er, ey - er * 1.2 + er * 2.3 * lid * 0.5, ex + er, ey - er * 1.2 + er * 2.3 * lid * 0.5, P(INK, 255, 4))
        brow = st.get("brow", 0.0)
        worried = st.get("worried", 0.0)
        by = ey - 42 - brow * 14
        bc = "#3a2b24" if who == "S" else "#6a3a28"
        cv.drawLine(ex - 18, by + worried * sgn * -8 * -1 * (1), ex + 18, by - worried * sgn * 8, P(bc, 255, 8))
    # nose
    cv.drawPath(oval(0, hy0 + 18, 12, 10), P("#e3a57f"))
    # mouth
    m = st.get("mouth", 0.0)
    my = hy0 + 58 if who == "S" else hy0 + 62
    if who == "S":
        must = skia.Path(); must.moveTo(-42, my - 8); must.quadTo(0, my - 30, 42, my - 8); must.quadTo(0, my - 14, -42, my - 8)
        fo(cv, must, "#4a3021", 4)
    if m > 0.08:
        mp = oval(0, my + 6 + 8 * m, 18 + 8 * m, 6 + 22 * m)
        fo(cv, mp, "#7d2534", 4)
        cv.drawPath(oval(0, my + 12 + 16 * m, 10 + 4 * m, 4 + 6 * m), P("#e0606f"))
    else:
        sm = skia.Path(); sm.moveTo(-18, my + 4); sm.quadTo(0, my + 4 + st.get("smile", 6), 18, my + 4)
        cv.drawPath(sm, P(INK, 255, 5))
    cv.restore()
    cv.restore()
    return hands


def cat(cv, x, y, s, st, t):
    """st: pose 'sit'|'loaf'|'leap'|'scream'|'walk'; face dir d; lid; mouth; tail"""
    pose = st.get("pose", "sit")
    d = st.get("d", 1)
    cv.save()
    cv.translate(x, y)
    cv.scale(s * d, s)
    cv.rotate(st.get("rot", 0))
    orange, dark, light = "#f39a3b", "#d6702a", "#fbd3a2"
    m = st.get("mouth", 0.0)
    breath = math.sin(t * 2.6) * 3
    if pose == "scream":
        cv.translate(0, -30 - abs(math.sin(t * 40)) * 6)
    # tail
    tw_ = math.sin(t * 2.2) * 14 + st.get("tail", 0)
    tp = skia.Path()
    if pose in ("sit", "scream"):
        tp.moveTo(-70, -20); tp.cubicTo(-150, -10, -160 + tw_, -110, -120 + tw_, -150)
    elif pose == "leap":
        tp.moveTo(-110, -60); tp.cubicTo(-170, -70, -210, -40, -240, -80 + tw_ * 0.5)
    else:
        tp.moveTo(-100, -30); tp.cubicTo(-160, -20, -170 + tw_, -80, -140 + tw_, -110)
    cv.drawPath(tp, P(INK, 255, 40)); cv.drawPath(tp, P(orange, 255, 28))
    # body
    if pose == "sit":
        body = oval(0, -90 + breath * 0.3, 92, 98 + breath * 0.5)
    elif pose == "scream":
        body = oval(0, -100, 100, 108)
    elif pose == "leap":
        body = oval(10, -80, 140, 62)
    else:  # loaf / walk
        body = oval(0, -62 + breath * 0.3, 128, 66)
    if pose == "scream":  # spiky fur
        sp = skia.Path()
        for i in range(28):
            a = i / 28 * math.tau
            r = (112 if i % 2 else 132)
            px, py = 0 + math.cos(a) * r, -100 + math.sin(a) * r * 1.05
            (sp.moveTo if i == 0 else sp.lineTo)(px, py)
        sp.close()
        fo(cv, sp, orange, 6)
    fo(cv, body, orange, 6)
    # stripes
    for i in range(3):
        if pose in ("sit", "scream"):
            cv.drawLine(-60 + i * 22, -170 + i * 6, -40 + i * 22, -140 + i * 6, P(dark, 255, 10))
        else:
            cv.drawLine(-40 + i * 34, -120, -30 + i * 34, -90, P(dark, 255, 10))
    # belly / paws
    if pose in ("sit", "scream"):
        cv.drawPath(oval(20, -70, 50, 60), P(light))
        fo(cv, oval(-20, -6, 30, 16), orange, 5)
        fo(cv, oval(40, -6, 30, 16), orange, 5)
    elif pose == "leap":
        fo(cv, oval(130, -60, 34, 14), orange, 5)
        fo(cv, oval(-110, -40, 34, 14), orange, 5)
    else:
        wp = st.get("wphase", 0)
        for px in (-70, 70):
            off = math.sin(wp + px) * 16 if pose == "walk" else 0
            fo(cv, oval(px + off, -6, 30, 14), orange, 5)
    # collar
    if st.get("collar"):
        pass
    # head
    hx, hy = (40, -190) if pose in ("sit", "scream") else ((150, -110) if pose == "leap" else (100, -110))
    if pose == "scream":
        hx, hy = 30, -205
    st["_neck"] = (x + d * s * (hx - 30), y + s * (hy + 60))
    cv.save(); cv.translate(hx, hy)
    cv.rotate(st.get("htilt", 0))
    ear_f = -20 if st.get("ears_flat") else 0
    for ex in (-1, 1):
        ep = poly([(ex * 30, -50), (ex * (62 + (-ear_f if ex > 0 else -ear_f) * 0.5), -110 - ear_f), (ex * 70, -34)])
        fo(cv, ep, orange, 5)
        cv.drawPath(poly([(ex * 40, -52), (ex * 60, -92 - ear_f), (ex * 62, -46)]), P("#f6b0a0"))
    fo(cv, oval(0, 0, 86, 74), orange, 6)
    cv.drawLine(-14, -70, -10, -46, P(dark, 255, 9)); cv.drawLine(10, -72, 10, -46, P(dark, 255, 9))
    cv.drawPath(oval(10, 28, 40, 26), P(light))
    lid = st.get("lid", 0.0)
    wide = st.get("wide", 0.0)
    for ex in (-30, 34):
        er = 20 + 10 * wide
        cv.drawPath(oval(ex, -8, er, er * 1.1), P("#a8d86a")); cv.drawPath(oval(ex, -8, er, er * 1.1), P(INK, 255, 4))
        cv.drawPath(oval(ex + 4 * st.get("look", 0), -8, 5 + 6 * wide, er * 0.9), P(INK))
        if lid >= 0.95:   # fully closed (sleeping)
            cv.drawPath(oval(ex, -8, er + 3, er * 1.1 + 3), P(orange))
            cl = skia.Path(); cl.moveTo(ex - er, -6); cl.quadTo(ex, 8, ex + er, -6)
            cv.drawPath(cl, P(INK, 255, 5))
        elif lid > 0:
            yy = -8 - er * 1.1 + er * 2.2 * lid * 0.55
            cv.drawRect(skia.Rect.MakeLTRB(ex - er - 3, -8 - er * 1.1 - 3, ex + er + 3, yy), P(orange))
            cv.drawLine(ex - er, yy, ex + er, yy + (4 if ex < 0 else -4), P(INK, 255, 5))
    cv.drawPath(poly([(2, 16), (18, 16), (10, 26)]), P("#e8708a"))
    if m > 0.08:
        fo(cv, oval(10, 44 + 10 * m, 14 + 14 * m, 4 + 26 * m), "#7d2534", 4)
        if pose == "scream":
            for fx in (-6, 26):
                cv.drawPath(poly([(fx, 36), (fx + 6, 36), (fx + 3, 48)]), P("#ffffff"))
    else:
        mp = skia.Path(); mp.moveTo(-6, 36); mp.quadTo(2, 44, 10, 34); mp.quadTo(18, 44, 26, 36)
        cv.drawPath(mp, P(INK, 255, 4))
    for wy in (24, 36):
        cv.drawLine(40, wy, 100, wy - 6, P(INK, 200, 3)); cv.drawLine(-20, wy, -80, wy - 6, P(INK, 200, 3))
    if st.get("collar"):
        cv.drawPath(oval(6, 66, 62, 12), P("#d93a3a"))
        cv.drawPath(oval(6, 66, 62, 12), P(INK, 255, 4))
        cv.drawCircle(6, 80, 9, P("#ffd34a")); cv.drawCircle(6, 80, 9, P(INK, 255, 3))
    cv.restore()
    cv.restore()
    return st["_neck"]


# ---------------------------------------------------------------- props
NS, NY, SS, SY = 0.9, 1480, 0.92, 1485
CATX, CATY = 880, 1650


# ---------------------------------------------------------------- overlays
def pill(cv, s, cx, cy, size=46, dots=True, a=255):
    w = tw(s, size) + (110 if dots else 60)
    h = size * 1.75
    x = cx - w / 2
    cv.drawPath(rrect(x, cy - h / 2, w, h, h / 2), P("#25213a", a))
    cv.drawPath(rrect(x, cy - h / 2, w, h, h / 2), P("#ffcf3f", a, 5))
    text(cv, s, x + 30 + tw(s, size) / 2, cy + size * 0.36, size, "#ffffff", a=a)
    if dots:
        for i in range(3):
            cv.drawCircle(x + w - 62 + i * 15, cy, 5.5, P("#ffcf3f", a if i < 2 else int(a * 0.5)))


def board(cv, lines, cx, cy, a=255, scale=1.0, w=640):
    """parchment inset board. lines: list of (text, size, color)"""
    cv.save(); cv.translate(cx, cy); cv.scale(scale, scale)
    hh = sum(int(sz * 1.3) for _, sz, _ in lines) + 60
    cv.drawPath(rrect(-w / 2 + 8, -hh / 2 + 12, w, hh, 26), P("#000000", int(a * 0.25)))
    cv.drawPath(rrect(-w / 2, -hh / 2, w, hh, 26), P("#efe0bd", a))
    cv.drawPath(rrect(-w / 2, -hh / 2, w, hh, 26), P("#7a5a3a", a, 8))
    cv.drawPath(rrect(-w / 2 + 16, -hh / 2 + 16, w - 32, hh - 32, 16), P("#c9ae82", a, 3))
    y = -hh / 2 + 30
    for s, sz, c in lines:
        y += sz * 1.1
        text(cv, s, 0, y, sz, c, a=a)
        y += sz * 0.2
    cv.restore()


KEYW = {"ЯЛИНКУ", "ЯЛИНКА", "ЯЛИНКОЮ", "ВЕРХІВЦІ", "МЕТР", "ВІСІМДЕСЯТ", "ВЕТЕРИНАРИ", "СТРИБАЮТЬ", "ДЕРЕВО", "ДЯКУЮ",
        "КУЛЬКИ", "ЗВЕРХУ", "ТРИ", "ЛАПОЮ", "ОЧІ", "ДОЩИК", "НЕБЕЗПЕЧНИЙ", "ЗАПАМ'ЯТАЮ", "ЛЕЖИТЬ", "КОРОЛЬ",
        "МОТУЗКОЮ", "СТЕЛІ", "ХОЛОДИЛЬНИК", "КОВБАСОЮ", "ФОЛЬГА", "НЕПРИЄМНО", "РІВНО", "МОРДОЧКА", "ФОЛЬЗІ",
        "МУРЧИТЬ", "ТЕПЛА", "ПОЧЕКАЄ", "КІТ", "СТОЇТЬ", "ДІСТАНЕ"}

def chunks(line):
    ws = line["words"]
    out = []
    i = 0
    while i < len(ws):
        grp = [ws[i]]
        if i + 1 < len(ws) and (len(ws[i]["w"]) <= 4 or len(ws[i + 1]["w"]) <= 3) and len(ws[i]["w"]) + len(ws[i + 1]["w"]) <= 15:
            grp.append(ws[i + 1])
        out.append(grp)
        i += len(grp)
    res = []
    for j, g in enumerate(out):
        t0 = g[0]["t"]
        t1 = out[j + 1][0]["t"] if j + 1 < len(out) else g[-1]["t"] + g[-1]["d"] + 0.35
        res.append((t0, t1, [w["w"] for w in g]))
    return res


CHUNKS = {l["id"]: chunks(l) for l in LINES}
SPC = {"S": "#3f80e8", "N": "#ec6a8c", "M": "#f39a3b"}
from script_data import NAMES


def subtitles(cv, t):
    for l in LINES:
        for t0, t1, ws in CHUNKS[l["id"]]:
            if t0 <= t < t1:
                k = clamp((t - t0) / 0.08)
                sc = 0.85 + 0.15 * smooth(k)
                cv.save(); cv.translate(540, 1730); cv.scale(sc, sc)
                # speaker tag
                nm = NAMES[l["sp"]]
                w = tw(nm, 30, FONT_XB) + 34
                cv.drawPath(rrect(-w / 2, -150, w, 46, 23), P(SPC[l["sp"]]))
                text(cv, nm, 0, -116, 30, "#ffffff", FONT_XB)
                s = " ".join(x.upper() for x in ws)
                size = 104
                while tw(s, size) > 980:
                    size -= 4
                x = -tw(s, size) / 2
                for wd in ws:
                    u = wd.upper()
                    c = "#ffd23f" if u.strip("!?.,…") in KEYW else "#ffffff"
                    text(cv, u, x, 0, size, c, align="l", outline=22)
                    x += tw(u + " ", size)
                cv.restore()
                return


# ---------------------------------------------------------------- scene state
def track_keys():
    T = {}
    s = {k: S(k) for k in LID}
    REST = ((-10, -4), (10, 4))
    HIPS = ((-30, 20), (30, -20))
    UP2 = ((-150, -150), (150, 150))
    SHRUG = ((-50, -120), (50, 120))
    POINT_R = ((-10, -4), (120, 150))
    T["n_arms"] = Track([
        (0, ((-10, -4), (140, 155))), (s["l02"], HIPS), (s["l03"], ((-40, -110), (40, 110))), (s["l03"] + 2.4, ((-20, -60), (60, 120))),
        (s["l04"], HIPS), (s["l05"], REST), (s["l06"], ((-10, -4), (130, 150))), (s["l06"] + 2.2, ((-40, -110), (40, 110))),
        (s["l07"], ((-10, -4), (60, 40))), (s["l08"], HIPS), (s["l09"], REST),
        (FALL - 0.2, ((-60, -120), (60, 120)), 0.2), (s["l10"], ((-10, -4), (140, 155))), (s["l11"], HIPS),
        (s["l12"], ((-35, -100), (30, 95))), (s["l12"] + 2.4, ((-20, -60), (70, 140))), (s["l13"], REST),
        (s["l14"], ((-10, -4), (130, 150))), (s["l15"], HIPS), (s["l16"], ((-10, -4), (110, 120))), (s["l17"], HIPS), (s["l18"], REST),
    ])
    T["n_look"] = Track([(0, 1), (s["l03"], 0.2), (s["l04"], 1), (s["l06"], 1), (s["l07"], 1),
                         (s["l10"], 1), (s["l12"], 0.2), (s["l13"], 1), (s["l14"], 1), (s["l16"], 1), (s["l18"], 0)])
    T["s_arms"] = Track([
        (0, ((-60, -120), (60, 120))), (wt("l01", "верхів"), POINT_R, 0.3), (s["l02"], ((-40, -110), (40, 110))), (s["l03"], HIPS),
        (s["l05"] - 0.7, ((-10, -4), (80, 70))), (HANG - 0.1, ((-10, -4), (140, 160)), 0.3), (HANG + 0.4, REST),
        (s["l06"], ((-20, -60), (20, 60))), (s["l07"] - 0.3, ((-25, -95), (10, 4))),
        (TOSS - 0.15, ((-150, -160), (10, 4)), 0.25), (TOSS + 0.4, REST, 0.3), (s["l09"], ((-20, -60), (20, 60))),
        (FALL - 0.2, UP2, 0.2), (s["l10"], ((-20, -60), (20, 60))),
        (s["l11"], ((-25, -95), (10, 4))), (TIE - 0.1, ((-150, -160), (10, 4)), 0.25), (TIE + 0.6, REST),
        (s["l12"], REST), (s["l13"] - 0.3, ((-10, -4), (80, 70))), (FOIL + 0.1, ((-10, -4), (60, 20)), 0.3), (FOIL + 0.8, REST),
        (s["l14"], REST), (s["l15"], SHRUG), (s["l16"], REST), (s["l17"], REST), (s["l18"], ((-40, -120), (40, 120))),
    ])
    T["s_look"] = Track([(0, 1), (s["l03"], -1), (s["l04"], 1), (s["l05"], 1), (s["l06"], -1), (s["l07"], -1),
                         (s["l08"], -1), (s["l09"], 1), (s["l10"], 1), (s["l11"], 1), (s["l12"], -1), (s["l13"], 1),
                         (s["l14"], 1), (s["l15"], -1), (s["l16"], 1), (s["l18"], 0)])
    T["n_x"] = Track([(0, 300), (FALL + 0.1, 230, 0.6), (TIE + 1.0, 300, 0.8)])
    T["s_x"] = Track([(0, 640), (FALL + 0.1, 700, 0.6), (TIE + 1.0, 640, 0.8)])
    return T


TR = track_keys()


def blink_of(t, seed):
    ph = (t + seed * 1.7) % 3.7
    return 0.1 if ph < 0.12 else 1.0


def inl(id_, t, pad=0.0):
    return S(id_) - pad <= t < E(id_) + pad


def moving(tr, t):
    return abs(tr(t + 0.05) - tr(t - 0.05)) > 0.5


ON_TREE = (0, -440)
CAT_FLOOR = (CATX - 90, CATY + 10)


def cat_place(t):
    """returns x, y, scale"""
    rot = tree_rot(t)
    if t < JUMP:
        x, y = tree_pt(0, -650, rot)
        return x, y, 0.55
    if t < JUMP + 0.5:
        k = (t - JUMP) / 0.5
        x0, y0 = tree_pt(0, -650, 0)
        x = lerp(x0, CAT_FLOOR[0], k); y = lerp(y0, CAT_FLOOR[1], k) - math.sin(k * math.pi) * 160
        return x, y, lerp(0.55, 1.0, k)
    if FALL - 0.5 <= t < FALL:
        k = (t - (FALL - 0.5)) / 0.5
        x1, y1 = tree_pt(*ON_TREE, 0)
        return lerp(CAT_FLOOR[0], x1, k), lerp(CAT_FLOOR[1], y1, k) - math.sin(k * math.pi) * 200, lerp(1.0, 0.75, k)
    if FALL <= t < TIE:
        x, y = tree_pt(*ON_TREE, rot)
        return x, y, 0.75
    if TIE <= t < TIE + 0.5:
        k = (t - TIE) / 0.5
        x0, y0 = tree_pt(*ON_TREE, -64)
        return lerp(x0, CAT_FLOOR[0], k), lerp(y0, CAT_FLOOR[1], k) - math.sin(k * math.pi) * 120, lerp(0.75, 1.0, k)
    if t >= MORNING:
        return TX + 60, TB + 40, 0.85
    return CAT_FLOOR[0], CAT_FLOOR[1], 1.0


def scene_state(t):
    st = {}
    nx = TR["n_x"](t); sx = TR["s_x"](t)
    n = dict(arms=TR["n_arms"](t), look=TR["n_look"](t), mouth=mouth_of("N", t), blink=blink_of(t, 1),
             walk=1.0 if moving(TR["n_x"], t) else 0, wphase=t * 9, brow=0.0)
    if n["mouth"] > 0:
        a = n["arms"]; g = math.sin(t * 5) * 8
        n["arms"] = (a[0], (a[1][0] + g, a[1][1] + g * 1.5))
        n["brow"] = 0.5 * n["mouth"]
    if inl("l06", t) or inl("l07", t) or FALL - 0.2 <= t < E("l10"):
        n["brow"] = 0.8; n["wide"] = 0.3
    if inl("l16", t):
        n["smile"] = 14
    st["N"] = (nx, n)
    s = dict(arms=TR["s_arms"](t), look=TR["s_look"](t), mouth=mouth_of("S", t), blink=blink_of(t, 2),
             walk=1.0 if moving(TR["s_x"], t) else 0, wphase=t * 9 + 1, robe=False)
    if s["mouth"] > 0:
        a = s["arms"]; g = math.sin(t * 4.3) * 7
        s["arms"] = (a[0], (a[1][0] + g, a[1][1] + g))
        s["brow"] = 0.4
    if t < S("l03"):
        s["wide"] = 0.5
    if inl("l06", t, 0.2) or FALL - 0.2 <= t < S("l11"):
        s["worried"] = 1; s["wide"] = 0.6
    if inl("l15", t):
        s["worried"] = 0.6
    st["S"] = (sx, s)
    x, y, sc = cat_place(t)
    c = dict(pose="sit", d=-1, lid=0.3, mouth=mouth_of("M", t), look=-1)
    if t < JUMP:
        c.update(lid=0.0, wide=0.4, tail=20)
    elif t < JUMP + 0.5 or FALL - 0.5 <= t < FALL or TIE <= t < TIE + 0.5:
        c.update(pose="leap", d=1 if FALL - 0.5 <= t < FALL else -1, lid=0.0, wide=0.5)
    elif inl("l04", t, 0.3):
        c.update(lid=0.5, look=-1)
    elif S("l05") <= t < S("l07") - 0.7:
        c.update(d=1, look=1, lid=0.1, wide=0.3)
        for ts in SWATS:   # swat: hop toward the tree
            if ts - 0.25 <= t < ts + 0.15:
                c.update(rot=-14, wide=0.7)
    elif S("l07") - 0.3 <= t < TOSS + 0.6:
        c.update(d=-1, look=-1, lid=0.0, wide=0.6)
    elif inl("l09", t, 0.3):
        c.update(lid=0.55, ears_flat=True, look=-1)
    elif FALL <= t < TIE:
        c.update(lid=0.5, htilt=-6, look=-1)
    elif TIE + 0.5 <= t < MORNING:
        c.update(d=1, look=1, lid=0.6, ears_flat=True)
    if t >= MORNING:
        c.update(pose="loaf", d=-1, lid=1.0, look=0)
        if inl("l17", t, 0.2):
            c.update(lid=0.7)
    st["M"] = (x, y, sc, c)
    return st


def camera(t):
    keys = [
        (0, (1.35, 860, 900)),
        (wt("l01", "верхів"), (1.6, 880, 780), 0.4),
        (S("l02"), (1.2, 760, 1000), 0.3),
        (S("l03"), (1.1, 420, 1000)),
        (JUMP, (1.05, 700, 1100), 0.3),
        (S("l04"), (1.65, CAT_FLOOR[0], 1560), 0.25),
        (S("l05") - 0.6, (1.0, 540, 960)),
        (S("l05") + 0.4, (1.2, 760, 900)),
        (S("l06"), (1.15, 600, 1150)),
        (SWATS[1], (1.3, 760, 1350), 0.3),
        (S("l07") - 0.6, (1.0, 540, 960)),
        (S("l07"), (1.2, 380, 1000)),
        (S("l08"), (1.25, 640, 1000)),
        (S("l09"), (1.6, CAT_FLOOR[0], 1540), 0.3),
        (FALL - 0.4, (1.0, 540, 960), 0.4),
        (S("l10"), (1.25, 480, 1150), 0.4),
        (S("l11"), (1.2, 700, 1000)),
        (TIE + 0.5, (1.0, 540, 960), 0.4),
        (S("l12"), (1.1, 400, 1000)),
        (S("l13"), (1.2, 800, 1150)),
        (MORNING, (1.0, 540, 960), 0.5),
        (S("l14") + 0.4, (1.15, 760, 900)),
        (S("l15"), (1.25, 640, 1000)),
        (S("l16"), (1.55, TX + 40, 1380), 0.4),
        (S("l17"), (1.8, TX + 40, 1400), 0.3),
        (S("l18"), (1.0, 540, 960), 0.6),
    ]
    z, x, y = Track(keys, 0.5)(t)
    z *= 1 + 0.012 * math.sin(t * 0.7)
    x += math.sin(t * 0.43) * 8
    if FALL + 0.4 <= t < FALL + 0.9:   # crash shake
        d = t - FALL - 0.4
        x += math.sin(d * 70) * 18 * (1 - d / 0.5); y += math.cos(d * 60) * 14 * (1 - d / 0.5)
    for lid_ in ("l04", "l09"):
        if S(lid_) <= t < E(lid_):
            for w in LID[lid_]["words"]:
                if w["t"] <= t < w["t"] + 0.12:
                    z *= 1.04
    z = max(z, 1.0)
    hw, hh = 540 / z, 960 / z
    x = clamp(x, hw, W - hw); y = clamp(y, hh, H - hh)
    return z, x, y


# ---------------------------------------------------------------- frame
def draw_frame(cv, t):
    z, cx, cy = camera(t)
    cv.clear(col("#000000"))
    cv.save()
    cv.translate(540, 960); cv.scale(z, z); cv.translate(-cx, -cy)
    draw_background(cv, t, (z, cx, cy))
    st = scene_state(t)
    nx, n = st["N"]; sx, s = st["S"]; ccx, ccy, csc, c = st["M"]
    human(cv, "N", nx, NY, NS, n, t)
    human(cv, "S", sx, SY, SS, s, t)
    lh, rh = s["_hands"]
    lh = (sx + lh[0] * SS, SY + lh[1] * SS); rh = (sx + rh[0] * SS, SY + rh[1] * SS)
    if S("l05") - 0.7 <= t < HANG:
        ball(cv, rh[0], rh[1] - 20, 26, "#e8453c")
    if S("l07") - 0.3 <= t < TOSS:
        tinsel(cv, lh[0], lh[1] - 20, -10)
    elif TOSS <= t < TOSS + 1.2:
        k = (t - TOSS) / 1.2
        tinsel(cv, lh[0] - 900 * k, lh[1] - 900 * k + 700 * k * k, -10 - 540 * k)
    if S("l11") - 0.1 <= t < TIE:
        rope_coil(cv, lh[0], lh[1] - 10)
    if S("l13") - 0.3 <= t < FOIL:
        foil_roll(cv, rh[0], rh[1] - 10)
    cat(cv, ccx, ccy, csc, c, t)
    if t >= MORNING and not inl("l17", t, 0.2):
        zzz(cv, ccx + 10, ccy - 190, t)
    cv.restore()
    k = tod(t)
    cv.drawRect(skia.Rect.MakeWH(W, H), skia.Paint(Shader=skia.GradientShader.MakeLinear(
        [(0, 1000), (0, H)], [col("#4a2f7a", 0), col("#3a2a6a", int(70 + 40 * clamp(k / 3)))])))
    cv.drawRect(skia.Rect.MakeWH(W, H), skia.Paint(Shader=skia.GradientShader.MakeRadial(
        (560, 520), 1000, [col("#ffd27a", 55), col("#ffd27a", 0)])))
    cv.drawRect(skia.Rect.MakeWH(W, H), skia.Paint(Shader=skia.GradientShader.MakeRadial(
        (540, 960), 1300, [col("#000000", 0), col("#1d1440", int(90 + 50 * clamp(k / 3)))])))
    if FALL + 0.35 <= t < FALL + 0.55:   # crash flash
        cv.drawRect(skia.Rect.MakeWH(W, H), P("#ffffff", int(120 * (1 - (t - FALL - 0.35) / 0.2))))
    overlays(cv, t)
    if t < S("l18"):
        subtitles(cv, t)
    else:
        cta(cv, t)


def burst(cv, r):
    p = skia.Path()
    for i in range(24):
        a = i / 24 * math.tau
        rr = r if i % 2 == 0 else r * 0.7
        (p.moveTo if i == 0 else p.lineTo)(math.cos(a) * rr * 1.25, math.sin(a) * rr * 0.8)
    p.close()
    fo(cv, p, "#e8453c", 8)


def fade_in_out(t, t0, t1, d=0.25):
    return clamp(min((t - t0) / d, (t1 - t) / d))


def fridge(cv, cx, cy, a, t):
    cv.save(); cv.translate(cx, cy)
    cv.drawPath(rrect(-300, -230, 600, 470, 26), P("#efe0bd", a))
    cv.drawPath(rrect(-300, -230, 600, 470, 26), P("#7a5a3a", a, 8))
    text(cv, "ДЛЯ КОТА ЯЛИНКА =", 0, -172, 40, "#5a3a20", a=a)
    # fridge body with open door
    fo(cv, rrect(-150, -130, 200, 340, 18), "#eef3f7", 6, a=a)
    cv.drawPath(rrect(-134, -114, 168, 308, 10), P("#fff6d8", a))
    for y in (-30, 70):
        cv.drawLine(-134, y, 34, y, P("#c9d1dc", a, 5))
    # sausage
    sw = math.sin(t * 3) * 3
    fo(cv, rrect(-120, -80 + sw, 140, 38, 19), "#c0504d", 5, a=a)
    for i in range(3):
        cv.drawCircle(-90 + i * 40, -62 + sw, 5, P("#f3c2b0", a))
    fo(cv, rrect(-110, 20, 60, 44, 6), "#ffd23f", 4, a=a)     # cheese
    fo(cv, oval(-10, 130, 34, 26), "#ffffff", 4, a=a)          # milk
    fo(cv, poly([(50, -130), (190, -100), (190, 190), (50, 210)]), "#dfe6ee", 6, a=a)   # door
    fo(cv, rrect(160, -20, 14, 70, 6), "#8f98a8", 3, a=a)
    # glow + hearts
    cv.drawCircle(-50, -40, 160, P("#fff6a0", int(a * 0.15)))
    for i, hx in enumerate((-230, 240)):
        y = 140 - (t * 40 + i * 30) % 60
        hp = skia.Path(); hp.moveTo(hx, y + 14); hp.cubicTo(hx - 30, y - 6, hx - 10, y - 24, hx, y - 8)
        hp.cubicTo(hx + 10, y - 24, hx + 30, y - 6, hx, y + 14)
        cv.drawPath(hp, P("#e8453c", a))
    cv.restore()


def overlays(cv, t):
    B = [
        (S("l02") + 0.2, E("l02") + 0.2, [("НОВА ЯЛИНКА", 54, "#5a3a20"), ("1,8 м", 120, "#2f8a4a")]),
        (S("l03") + 0.2, E("l03") + 0.4, [("КІТ СТРИБАЄ", 54, "#5a3a20"), ("до 1,8 м", 120, "#b0402a"),
                                          ("ветеринари: Preventive Vet, Catster", 26, "#6a5a4a")]),
        (wt("l08", "ветерин"), E("l08") + 0.3, [("ДОЩИК — НЕБЕЗПЕКА", 50, "#b0402a"), ("проковтнутий, ранить кишечник", 32, "#5a3a20"),
                                               ("Cornell Feline Health Center", 26, "#6a5a4a")]),
        (TIE - 0.3, E("l11") + 0.4, [("ПРИВ'ЯЖИ ДО СТЕЛІ", 50, "#b0402a"), ("гачок + мотузка", 36, "#5a3a20"),
                                     ("порада: Cornell Feline Health Center", 26, "#6a5a4a")]),
        (FOIL + 0.2, E("l13") + 0.3, [("ФОЛЬГА ДОВКОЛА", 50, "#b0402a"), ("котам неприємно під лапами", 34, "#5a3a20"),
                                      ("порада: Preventive Vet", 26, "#6a5a4a")]),
    ]
    for t0, t1, lines in B:
        a = fade_in_out(t, t0, t1, 0.2)
        if a > 0:
            k = clamp((t - t0) / 0.25)
            board(cv, lines, 540, 330, int(255 * a), 0.8 + 0.2 * smooth(k))
    a = fade_in_out(t, S("l12") + 0.1, E("l12") + 0.3, 0.2)
    if a > 0:
        k = clamp((t - S("l12")) / 0.3)
        cv.save(); cv.translate(540, 420); sc = 0.8 + 0.2 * smooth(k); cv.scale(sc, sc)
        fridge(cv, 0, 0, int(255 * a), t)
        cv.restore()


def cta(cv, t):
    k = clamp((t - S("l18")) / 0.4)
    cv.drawRect(skia.Rect.MakeWH(W, H), P("#1d1730", int(150 * k)))
    a = int(255 * k)
    cv.save(); cv.translate(540, 520); s = 0.8 + 0.2 * smooth(k); cv.scale(s, s)
    text(cv, "А ЩО ВАШ КІТ", 0, -90, 88, "#ffffff", outline=18, a=a)
    text(cv, "РОБИТЬ З", 0, 20, 92, "#ffffff", outline=18, a=a)
    text(cv, "ЯЛИНКОЮ?", 0, 130, 104, "#ffd23f", outline=18, a=a)
    cv.restore()
    pulse = 1 + 0.05 * math.sin(t * 6)
    cv.save(); cv.translate(540, 780); cv.scale(pulse, pulse)
    cv.drawPath(rrect(-210, -50, 420, 100, 50), P("#e8453c", a))
    text(cv, "ПІДПИСУЙСЯ", 0, 18, 50, "#ffffff", a=a)
    cv.restore()
    text(cv, "пиши в коментарях", 540, 900, 40, "#ffffff", FONT_XB, outline=10, a=a)
    text(cv, "Діалог вигаданий · мультфільм створено з допомогою ШІ", 540, 1840, 27, "#ffffff", FONT_SB, outline=8, a=a)
    text(cv, "Поради: Cornell Feline Health Center, Preventive Vet", 540, 1880, 27, "#ffffff", FONT_SB, outline=8, a=a)
    for t0, t1, ws in CHUNKS["l18"]:
        if t0 <= t < t1:
            text(cv, " ".join(w.upper() for w in ws), 540, 1730, 96, "#ffffff", outline=20)


# ---------------------------------------------------------------- main
def render_range(f0, f1, out):
    surf = skia.Surface(W, H)
    cv = surf.getCanvas()
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", f"{W}x{H}",
                          "-r", str(FPS), "-i", "-", "-c:v", "libx264", "-preset", "medium", "-crf", "18",
                          "-pix_fmt", "yuv420p", out], stdin=subprocess.PIPE)
    for f in range(f0, f1):
        draw_frame(cv, f / FPS)
        arr = surf.makeImageSnapshot().toarray(colorType=skia.kRGBA_8888_ColorType)
        p.stdin.write(arr.tobytes())
    p.stdin.close(); p.wait()


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "still":
        surf = skia.Surface(W, H)
        draw_frame(surf.getCanvas(), float(sys.argv[2]))
        surf.makeImageSnapshot().save(sys.argv[3], skia.kPNG)
    else:
        render_range(int(sys.argv[2]), int(sys.argv[3]), sys.argv[4])
