import sys, json, subprocess, skia
sys.argv=[sys.argv[0]]
import render as R
times=[float(x) for x in open('times.txt').read().split()]
W,H=270,480
cols=6; rows=(len(times)+cols-1)//cols
big=skia.Surface(W*cols,H*rows+0); c=big.getCanvas(); c.clear(skia.ColorBLACK)
s=skia.Surface(1080,1920)
for i,t in enumerate(times):
    R.draw_frame(s.getCanvas(),t)
    img=s.makeImageSnapshot()
    c.save(); c.translate((i%cols)*W,(i//cols)*H); c.scale(0.25,0.25); c.drawImage(img,0,0); c.restore()
    R.text(c,f"{t:.1f}",(i%cols)*W+30,(i//cols)*H+470,22,"#ffffff",outline=4)
big.makeImageSnapshot().save('stills/sheet.png',skia.kPNG)
