import asyncio, json, os, subprocess
import edge_tts
from script_data import LINES, VOICES

os.makedirs("tts", exist_ok=True)
PROXY = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")


async def one(line):
    v = VOICES[line["sp"]]
    c = edge_tts.Communicate(line.get("say", line["text"]), v["voice"], rate=v["rate"], pitch=v["pitch"],
                             boundary="WordBoundary", proxy=PROXY)
    audio = bytearray()
    words = []
    async for ch in c.stream():
        if ch["type"] == "audio":
            audio += ch["data"]
        elif ch["type"] == "WordBoundary":
            words.append(dict(t=ch["offset"] / 1e7, d=ch["duration"] / 1e7, w=ch["text"].replace("\u0301", "")))
    mp3 = f"tts/{line['id']}.mp3"
    open(mp3, "wb").write(audio)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", mp3, "-ar", "48000", "-ac", "1",
                    f"tts/{line['id']}.wav"], check=True)
    json.dump(words, open(f"tts/{line['id']}.json", "w"), ensure_ascii=False)
    return line["id"], len(words)


async def main():
    for l in LINES:
        for attempt in range(4):
            try:
                print(await one(l))
                break
            except Exception as e:
                print("retry", l["id"], e)
                await asyncio.sleep(2 * (attempt + 1))

asyncio.run(main())
