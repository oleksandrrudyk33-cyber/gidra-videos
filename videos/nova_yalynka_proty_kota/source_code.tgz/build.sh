#!/bin/bash
# Перезбирає відео з наявного tts/: timeline -> звук (−14 LUFS) -> кадри (3 потоки) -> mp4.
# Запуск у теці відео:  bash build.sh OUT.mp4
set -e
OUT=${1:-out.mp4}
python3 timeline.py > timeline.log
python3 audio.py
ffmpeg -v error -y -i mix_raw.wav -af loudnorm=I=-14:TP=-1.5:LRA=11 -ar 48000 -ac 2 mix.wav
TOTAL=$(python3 -c "import json;print(json.load(open('timeline.json'))['total'])")
N=$(python3 -c "import math;print(math.ceil($TOTAL*30))")
P=3; STEP=$(( (N + P - 1) / P ))
mkdir -p parts; : > parts/list.txt
for i in $(seq 0 $((P-1))); do
  A=$((i*STEP)); B=$(( (i+1)*STEP < N ? (i+1)*STEP : N ))
  python3 render.py frames $A $B parts/p$i.mp4 &
  echo "file 'p$i.mp4'" >> parts/list.txt
done
wait
ffmpeg -v error -y -f concat -safe 0 -i parts/list.txt -i mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest "$OUT"
echo "built $OUT ($TOTAL s)"
